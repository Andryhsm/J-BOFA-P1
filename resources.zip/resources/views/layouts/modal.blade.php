<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" id="confirm">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body title_modal_delete">
                Êtes-vous sur de supprimer?
            </div>
            <div class="modal-footer foot_modal_delete">
                <button type="button" data-dismiss="modal" class="btn btn-primary" id="delete">Supprimer</button>
                <button type="button" data-dismiss="modal" class="btn">Annuler</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div style="position: fixed;top: 0px;width: 100%;text-align: center; z-index: 999999;">
    <div class="notification_area" style="display:none;">Loading..</div>
</div>