<!--============================= FOOTER =============================-->
  <footer class="main-block dark-bg">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <div class="copyright">
                      <p>Copyright &copy; 2019. Tous droits réservés | <a href="#">Mentions Légales</a></p>
                      <ul>
                          <li><a href="#"><span class="ti-facebook"></span></a></li>
                          <li><a href="#"><span class="ti-twitter-alt"></span></a></li>
                          <li><a href="#"><span class="ti-instagram"></span></a></li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
  </footer>
  <!--//END FOOTER -->
