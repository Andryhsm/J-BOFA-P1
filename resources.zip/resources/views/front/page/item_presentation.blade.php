<section class="content_page_how_work">
  <label for="" class="title_content">COMMENT ÇA MARCHE ?</label>
  <div class="item_liste_how_work">
    <div class="how_work_item">
      <div class="image_liste_work">
        <img src="{!! url('/image/front/how_work/how2.jpg') !!}" class="" alt="" />
      </div>
      <div class="text_how_work">
        <label for="" class="title_how_work">Contactez et signez </label>
        <label for="" class="text_descr">Nos professionnels signent 1 à 2 projets sur 5</label>
      </div>
    </div>

    <div class="separator_item">
      <i class="fa fa-long-arrow-right"></i>
    </div>
    <div class="how_work_item">
      <div class="image_liste_work">
        <img src="{!! url('/image/front/how_work/how3.jpg') !!}" class="" alt="" />
      </div>
      <div class="text_how_work">
        <label for="" class="title_how_work">Consultez les chantiers</label>
        <label for="" class="text_descr">Accédez à toutes les demandes détaillées</label>
      </div>
    </div>
    <div class="separator_item">
      <i class="fa fa-long-arrow-right"></i>
    </div>
    <div class="how_work_item">
      <div class="image_liste_work">
        <img src="{!! url('/image/front/how_work/how1.jpg') !!}" class="" alt="" />
      </div>
      <div class="text_how_work">
        <label for="" class="title_how_work">Créez votre compte</label>
        <label for="" class="text_descr">Sélectionnez vos métiers et votre zone géographique</label>
      </div>
    </div>

  </div>
</section>
