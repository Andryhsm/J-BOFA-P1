<section id="footer_page">
  <div class="footer_page">
    <div class="content_footer">
      <div class="liste_link">
        <div class="item_link">
          <label for="" class="title_link">Services Pro</label>
          <a href="#" class="link_footer">S'inscrire</a>
          <a href="#" class="link_footer">Comment ça marche</a>
          <a href="#" class="link_footer">Aide</a>
          <a href="#" class="link_footer">Application mobile</a>
          <a href="#" class="link_footer">Mon espace</a>
        </div>
        <div class="item_link">
          <label for="" class="title_link">Services Particuliers</label>
          <a href="#" class="link_footer">Demander des devis</a>
          <a href="#" class="link_footer">Comment ça marche</a>
          <a href="#" class="link_footer">Aide</a>
          <a href="#" class="link_footer">Guide Travaux</a>
          <a href="#" class="link_footer">Trouver un pro</a>
          <a href="#" class="link_footer">Mon espace</a>
        </div>
        <div class="item_link">
          <label for="" class="title_link">Presse & Partenaires</label>
          <a href="#" class="link_footer">Revue de presse</a>
          <a href="#" class="link_footer">Kit média</a>
          <a href="#" class="link_footer">Affiliation</a>
          <a href="#" class="link_footer">Partenariat</a>
        </div>
      </div>
    </div>
  </div>
</section>
